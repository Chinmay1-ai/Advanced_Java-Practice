package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Bill;

public class BillDAO {

	public boolean createBill(int patientId, double amount) {

		boolean success = false;

		try {
			Connection con = DBConnection.getConnection();

			String sql = "INSERT INTO bills (patient_id, total_amount, status) VALUES (?, ?, 'UNPAID')";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setInt(1, patientId);
			ps.setDouble(2, amount);

			success = ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return success;
	}

	public List<Bill> getBillsByPatient(int patientId) {

		List<Bill> list = new ArrayList<>();

		try {
			Connection con = DBConnection.getConnection();

			String sql = "SELECT * FROM bills WHERE patient_id=? ORDER BY bill_id DESC";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, patientId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Bill bill = new Bill();

				bill.setBillId(rs.getInt("bill_id"));
				bill.setPatientId(rs.getInt("patient_id"));
				bill.setTotalAmount(rs.getDouble("total_amount"));
				bill.setStatus(rs.getString("status"));

				list.add(bill);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}