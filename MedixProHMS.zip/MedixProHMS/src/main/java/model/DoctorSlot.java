package model;

import java.sql.Date;
import java.sql.Time;

public class DoctorSlot {

	private int slotId;
	private int doctorId;
	private Date slotDate;
	private Time slotTime;
	private boolean isBooked;

	public int getSlotId() {
		return slotId;
	}

	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public Date getSlotDate() {
		return slotDate;
	}

	public void setSlotDate(Date slotDate) {
		this.slotDate = slotDate;
	}

	public Time getSlotTime() {
		return slotTime;
	}

	public void setSlotTime(Time slotTime) {
		this.slotTime = slotTime;
	}

	public boolean isBooked() {
		return isBooked;
	}

	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}
}